//
//  GoodToGo
//
//  Created by Ricardo Santos on 26/08/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

import Foundation

// Encapsulate API Responses
public struct GalleryAppResponseDto {
    private init() { }
}
