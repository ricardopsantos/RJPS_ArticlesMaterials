//
//  GoodToGo
//
//  Created by Ricardo Santos on 19/07/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

import Foundation
//
import Domain
import AppResources

public struct Factory {
    private init() {}
}
