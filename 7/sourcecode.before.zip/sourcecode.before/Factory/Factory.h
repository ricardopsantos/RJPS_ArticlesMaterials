//
//  GoodToGo
//
//  Created by Ricardo Santos on 11/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Factory.
FOUNDATION_EXPORT double FactoryVersionNumber;

//! Project version string for Factory.
FOUNDATION_EXPORT const unsigned char FactoryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Factory/PublicHeader.h>


