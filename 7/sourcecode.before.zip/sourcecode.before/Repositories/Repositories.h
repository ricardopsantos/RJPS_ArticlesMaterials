//
//  GoodToGo
//
//  Created by Ricardo Santos on 10/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Repositories.
FOUNDATION_EXPORT double RepositoriesVersionNumber;

//! Project version string for Repositories.
FOUNDATION_EXPORT const unsigned char RepositoriesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Repositories/PublicHeader.h>


