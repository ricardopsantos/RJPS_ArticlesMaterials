#  AppResources

## About

Contains suport for the app string (Localisable), Images, and so on

