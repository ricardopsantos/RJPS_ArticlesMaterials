#  AppResources

## About

Contains suport for the app string (Localisable), Images, and so on

## 23038-animatonblue.json

* https://lottiefiles.com/23038-animatonblue#
* https://assets7.lottiefiles.com/packages/lf20_YXD37q.json
* https://edit.lottiefiles.com/?src=https%3A%2F%2Fassets7.lottiefiles.com%2Fpackages%2Flf20_YXD37q.json
