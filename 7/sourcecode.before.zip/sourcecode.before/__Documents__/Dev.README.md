# Test deeplinks 

__Test deeplinks __

```
xcrun simctl openurl booted "myappdeeplink://questions?question_filter=FILTER"
xcrun simctl openurl booted "myappdeeplink://questions?question_id=QUESTION_ID"
xcrun simctl openurl booted "myappdeeplink://questions?question_id=1"
```

#  Xcode tips

* [⌥] -> Options 
* [⌘] -> Command
* [⇧] -> Shift
* [alt] -> Alt

----

* Indent code
    * Control + I
    
* Open quicky
    * ⌘ + ⇧ + O
    
* Clean Project
    * ⌘ + ⇧ + K
    * ⌘ + K

* Xcode Code Sniptes
    * ⌘ + ⇧ + L
