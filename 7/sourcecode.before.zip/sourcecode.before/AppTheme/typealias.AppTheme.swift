//
//  GoodToGo
//
//  Created by Ricardo Santos on 09/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

//swiftlint:disable rule_UIColor_1 rule_UIFont_1

import UIKit
import Foundation
//
import RJSLibUFAppThemes
//
import Extensions

public struct AppTheme {
    private init() {}
}

public typealias AppColors = UIColor.App
public typealias AppFonts  = RJSLibUFAppThemes.RJS_Fonts
public typealias ColorName = RJSLibUFAppThemes.RJS_ColorName
