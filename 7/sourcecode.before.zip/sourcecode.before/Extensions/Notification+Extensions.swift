//
//  GoodToGo
//
//  Created by Ricardo P Santos
//  Copyright ©  Ricardo P Santos. All rights reserved.
//

import UIKit
import Foundation

public extension Notification.Name {
    static let didReceiveData = Notification.Name("didReceiveData")
}
