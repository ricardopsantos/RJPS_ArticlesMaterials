#  AppDomain

* Contains the _protocols_ and app _Models / ViewModesl_

