//
//  GoodToGo
//
//  Created by Ricardo Santos on 09/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

import Foundation
import DevTools
import RJSLibUFStorage

// MARK: - DevTools

public typealias CacheStrategy = RJS_CacheStrategy
