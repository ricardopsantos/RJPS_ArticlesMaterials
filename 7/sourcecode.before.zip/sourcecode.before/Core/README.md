#  AppCore

Implements what defined on `AppDomain`

