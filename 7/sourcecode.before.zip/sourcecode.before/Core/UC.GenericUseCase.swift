//
//  GoodToGo
//
//  Created by Ricardo P Santos
//  Copyright ©  Ricardo P Santos. All rights reserved.
//

import Foundation
import UIKit
import RxSwift
import RxCocoa
import Domain

open class GenericUseCase: AppUtilsProtocol {
    public init() { }
}
