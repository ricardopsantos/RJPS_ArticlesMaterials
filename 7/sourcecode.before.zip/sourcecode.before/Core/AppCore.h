//
//  GoodToGo
//
//  Created by Ricardo Santos on 09/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AppCore.
FOUNDATION_EXPORT double AppCoreVersionNumber;

//! Project version string for AppCore.
FOUNDATION_EXPORT const unsigned char AppCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppCore/PublicHeader.h>


