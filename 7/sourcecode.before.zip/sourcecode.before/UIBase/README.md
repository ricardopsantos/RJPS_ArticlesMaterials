#  UIBase/AppBase

## About

Contains the app base classes (parent classes for the usual classes used on a VMP app)
