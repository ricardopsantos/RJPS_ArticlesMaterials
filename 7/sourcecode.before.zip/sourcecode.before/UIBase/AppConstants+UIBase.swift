//
//  GoodToGo
//
//  Created by Ricardo P Santos
//  Copyright ©  Ricardo P Santos. All rights reserved.
//

// Constants that are shared (existing) in the the app's and UI TESTS

import AppConstants

extension AppConstants {
    
    public struct UIViewControllers {
        private init() {}
        //private static let accessibilityIdentifierPrefix = "acId"
        //public static func genericAccessibilityIdentifier(_ controller: BaseViewControllerMVP) -> String {
        //    return "\(accessibilityIdentifierPrefix).\(controller.className)"
        //}
    }
}
