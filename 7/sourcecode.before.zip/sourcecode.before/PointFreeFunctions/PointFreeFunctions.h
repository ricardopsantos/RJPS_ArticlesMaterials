//
//  GoodToGo
//
//  Created by Ricardo Santos on 09/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PointFreeFunctions.
FOUNDATION_EXPORT double PointFreeFunctionsVersionNumber;

//! Project version string for PointFreeFunctions.
FOUNDATION_EXPORT const unsigned char PointFreeFunctionsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PointFreeFunctions/PublicHeader.h>


