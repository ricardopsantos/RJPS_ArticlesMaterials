//
//  GoodToGo
//
//  Created by Ricardo Santos on 09/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DevTools.
FOUNDATION_EXPORT double DevToolsVersionNumber;

//! Project version string for DevTools.
FOUNDATION_EXPORT const unsigned char DevToolsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DevTools/PublicHeader.h>


