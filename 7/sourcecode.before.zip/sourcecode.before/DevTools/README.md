#  DevTools

## About

Project Swiss knife. Have lots of utilities to help developing. Some of the things are the _All Logger_ or a way to enable or not feature on the app _FeatureFlag_ according to the app environment (Prod, QA, Dev...)

This module should be extremely independent from the app and could work in any app just by _drag and drop_
