#  AppContants

## About

Constains the app contants and main `enums`

