//
//  GoodToGo
//
//  Created by Ricardo Santos on 09/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AppConstants.
FOUNDATION_EXPORT double AppConstantsVersionNumber;

//! Project version string for AppConstants.
FOUNDATION_EXPORT const unsigned char AppConstantsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppConstants/PublicHeader.h>


