//
//  GoodToGo
//
//  Created by Ricardo Santos on 10/05/2020.
//  Copyright © 2020 Ricardo P Santos. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for API.
FOUNDATION_EXPORT double APIVersionNumber;

//! Project version string for API.
FOUNDATION_EXPORT const unsigned char APIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <API/PublicHeader.h>


