#  Repositories.WebAPI

Simple, basic WebAPI logic only. __No rules, no cache, just requests__

