//
//  AutenticationModel.swift
//
//  Created by Ricardo Santos on 02/01/2021.
//

import Foundation
import Vapor

struct AutenticationModel: Content {
  let user: String
  let password: String
}

