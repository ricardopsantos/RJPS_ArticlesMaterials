//
//  GreetingModel.swift
//
//  Created by Ricardo Santos on 02/01/2021.
//

import Vapor
import Fluent
import FluentPostgresDriver

public final class GreetingModel: Model, Content {
    
    public static let schema = "greeting"

    @ID(custom: "id")
    public var id: Int?

    @Field(key: "from")
    var greetingFrom: String
    
    public init() {
        self.greetingFrom = ""
    }
    
    public init(greetingFrom: String = "") {
        self.greetingFrom = greetingFrom
    }

}
