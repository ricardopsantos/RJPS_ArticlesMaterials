import Fluent
import FluentPostgresDriver
import Vapor

// configures your application
public func configure(_ app: Application) throws {
    // uncomment to serve files from /Public folder
    // app.middleware.use(FileMiddleware(publicDirectory: app.directory.publicDirectory))

    do {
        let dbConnection: String = Environment.get("CONNECTION_STRING")!
        try app.databases.use(.postgres(url: dbConnection), as: .psql)
    } catch {
        app.logger.error(Logger.Message(stringLiteral: error.localizedDescription))
    }

    if let results = try? GreetingModel.query(on: app.db).all().wait() {
        print("--------------------")
        print(results as Any)
    }
    
    GreetingModel.query(on: app.db).all().always({ (result) in
        print("--------------------")
        print(result)
    })

    app.migrations.add(CreateTodo())

    // register routes
    try routes(app)
}
