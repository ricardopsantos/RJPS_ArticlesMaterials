import Fluent
import Vapor

func routes(_ app: Application) throws {
    app.get { req in
        return "It works!"
    }

    app.get("hello") { req -> String in
        return "Hello, world!"
    }

    app.get("hello", "joe") { req -> String in
        return "Hi Joe!"
    }
    
    app.get("hello", ":someone") { req -> String in
        guard let name = req.parameters.get("someone") else { throw Abort(.internalServerError) }
        return "Hello \(name)."
    }
    
    app.post("login") { req -> String in
        let data = try req.content.decode(AutenticationModel.self)
        if data.password == "1" && data.user.lowercased() == "Ricardo".lowercased() {
            return  "Hello \(data.user)"
        } else {
            return "Nice try..."
        }
    }
    
    app.get("greetings_crash") { req -> EventLoopFuture<[GreetingModel]> in
        let db = Bool.random() ? req.db : app.db
        if let results = try? GreetingModel.query(on: app.db).all().wait() {
            print(results as Any)
        }
        return GreetingModel.query(on: db).all()
    }
    
    app.get("greetings") { req -> EventLoopFuture<[GreetingModel]> in
        let db = Bool.random() ? req.db : app.db
        return GreetingModel.query(on: db).all()
    }
    
    app.post("greetings", "add") { req -> EventLoopFuture<GreetingModel> in
        let record = try req.content.decode(GreetingModel.self)
        let db = Bool.random() ? req.db : app.db
        return record.create(on: db).map { record }
    }
    
    try app.register(collection: TodoController())
}
